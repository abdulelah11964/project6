This project is submitted to udacity
First step open file index.html

This offers you the best ten places for me in the city of Riyadh in the Kingdom of Saudi Arabia

some of it :

1 - The house where I live
2 - The best coffee shop for me
3 - Place my favorite sport
4 - The places I love to spend my time in