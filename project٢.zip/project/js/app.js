var appViewModel;
var initialLocations = [{
        name: 'my home',
        location: {
                lat: 24.624353,
                lng: 46.564908
        },
        phone: '0500213623',
        email: 'abdullah11964@gmail.com'

}, {
        name: 'food highway',
        location: {
                lat: 24.631280,
                lng: 46.563246
        },
        phone: '052298635',
        email: 'highway@gmail.com'
}, {
        name: 'java coffee',
        location: {
                lat: 24.692468,
                lng: 46.91117
        },
        phone: '0113453235',
        email: 'java_coffee@gmail.com'
}, {
        name: 'king abdullah city',
        location: {
                lat: 24.733153,
                lng: 46.752104
        },
        phone: '011125346',
        email: 'king_abdullah_city@gmail.com'
}, {
        name: 'king khalid international airport',
        location: {
                lat: 24.940059,
                lng: 46.709789
        },
        phone: '011854303',
        email: 'king_khalid–international_airport@gmail.com'
}, {
        name: 'students houding maintenance center',
        location: {
                lat: 24.722623,
                lng: 46.623236
        },
        phone: '02129323',
        email: 'students_houding_maintenance_center@gmail.com'
}, {
        name: 'College of Computer and Information Sciences',
        location: {
                lat: 24.723052,
                lng: 46.620468
        },
        phone: '050023421',
        email: 'College_of_Computer_and_Information_Sciences@gmail.com'
}, {
        name: 'Imam Muhammad Ibn Saud Islamic University',
        location: {
                lat: 24.820503,
                lng: 46.700461
        },
        phone: '011584932',
        email: 'Imam_Muhammad_Ibn_Saud_Islamic_University@gmail.com'
}, {
        name: 'Starbucks Cafe',
        location: {
                lat: 24.687009,
                lng: 46.675296
        },
        phone: '053201434',
        email: 'Starbucks_Cafe@gmail.com'
}, {
        name: 'King Fahd International Stadium',
        location: {
                lat: 24.787054,
                lng: 46.842110
        },
        phone: '011654739',
        email: 'King_Fahd_International_Stadium@gmail.com'
}];
var mmap;

var mar;

mar = [];

function MAPP() {

        mmap = new google.maps.Map(document.getElementById("map"), {
                center: {
                        lat: 24.713552,
                        lng: 46.675296
                },
                zoom: 11
        });
        var info = new google.maps.InfoWindow();
        for (x = 0; x < initialLocations.length; x++) {
                var name = initialLocations[x].name;
                var location = initialLocations[x].location;
                var email = initialLocations[x].email;
                var phone = initialLocations[x].phone;
                var rok = new google.maps.Marker({
                        position: location,
                        map: mmap,
                        name: name,
                        phone: phone,
                        email: email,

                        ani: google.maps.Animation.DROP
                });

                mar.push(rok)
                appViewModel.myLocations()[x].rok = rok;
                rok.addListener('click', function() {
                        populateInfoWindow(this, info);
                });

                function populateInfoWindow(rok, baa) {
                        if (baa.rok != rok) {
                                baa.rok = rok;
                                baa.setContent(
                                        '<div class="title">' +
                                        '<p> name : </p>' + rok.name +
                                        '<br> <p> email : </p>' + rok.email +
                                        '<br> <p> phone : </p>' + rok.phone +
                                        '</div>'
                                );
                                rok.setAnimation(google.maps.Animation.BOUNCE);
                                setTimeout(function() {
                                        rok.setAnimation(null);
                                }, 1430);
                                baa.open(mmap, rok);
                                baa.addListener('her you can ', function() {
                                        baa.setMarker = null;
                                });
                        }
                }
                $.ajax({
                        // type: 'GET',
                        // url: foursquareUrl,
                        // success: function(data){
                        //         console.log(data);
                        // },
                        // error: function(){
                        //         console.log("It's taking longer than expected to retrieve data from foursquare. Please try again.");
                        // }
                });

        
                var foursquareUrl = "https://api.foursquare.com/v2/venues" + rok.position.lat() + "," + rok.position.lng() + "&client_id=" + x1 + "&client_secret=" + x2;




        }
}

var Location = function(some) {
        var self = this;
        this.isVisible = ko.observable(true);
        this.title = some.name;
        this.location = some.location;

};






var tee = function() {
        this.myLocations = ko.observableArray();
        var test = this;



        for (i = 0; i < initialLocations.length; i++) {
                var place = new Location(initialLocations[i]);
                test.myLocations.push(place);
        }

};

var x1 = "FZPMCSEYO134W0XYREE1QGP5TE4OXP2Z4QXCNAATK3MKIME0";
var x2 = "YGNCPSLBHXFWEFRWR3E3I4JUV3YHMKT0J3I53GDNTAVOUTXM";

appViewModel = new tee();

ko.applyBindings(appViewModel);